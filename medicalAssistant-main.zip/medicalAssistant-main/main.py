def main():
    print("Hello from medicalassistant!")


if __name__ == "__main__":
    main()
