# API_URL="http://127.0.0.1:8000"
API_URL="https://medicalassistant-wl4w.onrender.com"